﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	public Vector3 maxVelocity;
	private Vector3 velocity;
	public Collider platform = null;
	//Collider sidePlatform = null;
	bool canJump = false;
	public bool leftWall = false;
	public bool rightWall = false;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update()
	{
		velocity.x = maxVelocity.x * Input.GetAxis("Horizontal");
		if (leftWall && velocity.x > 0)
			velocity.x = 0;
		if (rightWall && velocity.x < 0)
			velocity.x = 0;

		/*if (platform)
		{
			Moving_Platform mp = platform.gameObject.GetComponent<Moving_Platform>();
			if(mp)
				velocity.x += mp.velocity.x;
		}*/
		
		if (Input.GetButton("Jump")) {
			if (platform)
			{
				platform = null;
				velocity.y += maxVelocity.y;
			}
			else if(canJump)
			{
				velocity -= 0.5F * Physics.gravity * Time.deltaTime;
			}
		}
		else if (!platform)
		{
			canJump = false;
		}
		
		// Not necessarily framerate independent
		Collider myCol = GetComponent<Collider>();
		if (!platform ||
		    myCol.bounds.max.x <= platform.bounds.min.x ||
		    myCol.bounds.min.x >= platform.bounds.max.x)
		{
			velocity += Physics.gravity * Time.deltaTime;
		}
		
		//Vector3 pos = transform.position; // Turn it into a variable
		transform.position += velocity * Time.deltaTime;
		
		//transform.position = pos;
	}
	
	void OnTriggerEnter(Collider col)
	{
		//print("Collision detected.");
		

		canJump = true;
		
		Collider myCol = GetComponent<Collider>();
		Vector3 pos = transform.position; // Turn it into a variable

		// If the player is on the ground and not touching its corners,
		// keep them on the ground
		if( myCol.bounds.min.y > col.bounds.max.y - .1F
		   && myCol.bounds.max.x != col.bounds.min.x
		   && myCol.bounds.min.x != col.bounds.max.x)
		{
			pos.y = col.bounds.max.y + transform.localScale.y / 2;
			platform = col;
			velocity.y = 0.0F;
		}
		// Otherwise, inside the left, right, bottom, or top somewhere
		else
		{
			Vector3 closest = col.ClosestPointOnBounds(transform.position);
			float relx = (closest.x - col.bounds.min.x) / col.bounds.size.x;
			float rely = (closest.y - col.bounds.min.y) / col.bounds.size.y;
			float relxOpp = 1.0F - relx;
			float relyOpp = 1.0F - rely;
			
			if ( relyOpp < rely && relyOpp < relx && relyOpp < relxOpp)
			{
				// Top
				pos.y = col.bounds.max.y + transform.localScale.y / 2;
				velocity.y = 0.0F;
				platform = col;
			}
			else if (relx <= rely && relx <= relxOpp && relx <= relyOpp)
			{
				// Left
				pos.x = col.bounds.min.x - transform.localScale.x / 2;
				velocity.x = 0.0F;
				leftWall = true;
			}
			else if (rely < relxOpp && rely < relyOpp)
			{
				// Bottom
				if(!platform)
				{
					pos.y = col.bounds.min.y - transform.localScale.y / 2;
					velocity.y = 0.0F;
				}
			}
			else if (relxOpp <= relyOpp)
			{
				// Right
				pos.x = col.bounds.max.x + transform.localScale.x / 2;
				velocity.x = 0.0F;
				rightWall = true;
			}
		}
		

		transform.position = pos;
	}
	
	void OnTriggerStay(Collider col)
	{
		OnTriggerEnter(col);
	}
	
	void OnTriggerExit(Collider col)
	{
	 	platform = null;
		leftWall = false;
		rightWall = false;
	}
}

