﻿using UnityEngine;
using System.Collections;

public class Camera : MonoBehaviour {

	public GameObject player;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 pos = player.transform.position;
		pos.z = -10;
		transform.position = pos;
	}
}
