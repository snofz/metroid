﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour {
	public int health;
	public int strength;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void damage(int damageAmount){
		health -= damageAmount;
		if(health <= 0)
			die ();
	}

	void die(){
		Destroy (this.gameObject);
	}
}
