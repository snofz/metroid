﻿using UnityEngine;
using System.Collections;

public class CamBox : MonoBehaviour {
	
	public GameObject player;
	public float magnitudey;
	public float magnitudex;

	// Use this for initialization
	void Start () {
		Vector3 scale = transform.localScale;
		scale.x = 2f * magnitudex;
		scale.y = 2f * magnitudey;
		transform.localScale = scale;
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 pos = transform.position;
		if (player.transform.position.x > transform.position.x + magnitudex)
			pos.x = player.transform.position.x - magnitudex;
		else if (player.transform.position.x < transform.position.x - magnitudex)
			pos.x = player.transform.position.x + magnitudex;
		if (player.transform.position.y > transform.position.y + magnitudey)
			pos.y = player.transform.position.y - magnitudey;
		else if (player.transform.position.y < transform.position.y - magnitudey)
			pos.y = player.transform.position.y + magnitudey;
		transform.position = pos;
	}
}
