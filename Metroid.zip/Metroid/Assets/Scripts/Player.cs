﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	private int health = 30;
	private int max_health = 99;
	private int energy_tank_number = 0;



	public GUIText health_text;
	public Vector3 maxVelocity;
	private Vector3 velocity;
	public Collider platform = null;
	public Material matMorph;
	public Material matStand;
	public Material matSpin;

	public float invincibility_time;
	private float current_invincibility_time;
	private Vector3 knockback;
	public float knockback_time;
	private float knockback_current_time;
	public float knockback_magnitude;

	bool canJump = false;
	bool spinning = false;
	bool leftWall = false;
	bool rightWall = false;
	bool invincible = false;

	public bool canMorph = false;
	public bool isMorph = false;
	public bool longBeam = false;
	
	public GameObject bulletFab;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update()
	{
		velocity.x = maxVelocity.x * Input.GetAxisRaw("Horizontal");

		if (knockback_current_time < knockback_time)
		{
			velocity = knockback;
			knockback_current_time += Time.deltaTime;
		}

		if (leftWall && velocity.x > 0)
			velocity.x = 0;
		if (rightWall && velocity.x < 0)
			velocity.x = 0;

		if(Input.GetAxis("Vertical") < 0 && canMorph && !isMorph && platform){
			renderer.material = matMorph;
			Vector3 scale = transform.localScale;
			scale.y = .99f;
			transform.localScale = scale;
			isMorph = true;
		}
		else if(Input.GetAxis ("Vertical")>0 && isMorph){
			unMorph();
		}
		
		if (Input.GetButton("Jump")) {
			if(isMorph)
				unMorph ();
			else{
				if (platform)
				{
					platform = null;
					velocity.y += maxVelocity.y;
					if(Input.GetAxisRaw("Horizontal") == 1
					   || Input.GetAxisRaw("Horizontal") == -1)
						SpinJump();
				}
				else if(canJump)
				{
					velocity -= 0.5F * Physics.gravity * Time.deltaTime;
				}
			}
		}
		else if (Input.GetButtonUp ("Jump") && canJump && velocity.y > 0)
		{
			velocity.y = 0;
			canJump = false;
		}
		else if (!platform)
		{
			canJump = false;
		}

		if(Input.GetButtonDown("Fire1")){
			shoot();
		}
		
		// Not necessarily framerate independent
		Collider myCol = GetComponent<Collider>();
		if (!platform ||
		    myCol.bounds.max.x <= platform.bounds.min.x ||
		    myCol.bounds.min.x >= platform.bounds.max.x)
		{
			velocity += Physics.gravity * Time.deltaTime;
		}
		
		//Vector3 pos = transform.position; // Turn it into a variable
		transform.position += velocity * Time.deltaTime;

		// Update invicibility time
		if(invincible)
		{
			if(current_invincibility_time > invincibility_time)
			{
				invincible = false;
				current_invincibility_time = 0F;
			}
			else
				current_invincibility_time += Time.deltaTime;
		}
	}
	
	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.CompareTag("Player_Bullet"))
			return;
		if (col.gameObject.CompareTag ("Wall"))
			GroundCollision (col);
		if (col.gameObject.CompareTag ("Enemy"))
			EnemyCollision (col);
	}

	void unMorph(){
		//Test if something is above samus
		/*IF BOX NOT DIRECTLY ABOVE, CAN STILL STAND*/
		RaycastHit hit;
		if(!Physics.Raycast(transform.position, Vector3.up, out hit, 1.0f) || !hit.collider.gameObject.CompareTag("Wall")){
			//If there is not a block, unmorph
			renderer.material = matStand;
			Vector3 scale = transform.localScale;
			scale.y = 1.99f;
			transform.localScale = scale;
			velocity.y = 0.0f;
			isMorph = false;
		}
	}


	void OnTriggerStay(Collider col)
	{
		OnTriggerEnter(col);
	}
	
	void OnTriggerExit(Collider col)
	{
	 	platform = null;
		leftWall = false;
		rightWall = false;
	}

	void GroundCollision(Collider col)
	{
		canJump = true;

		Collider myCol = GetComponent<Collider>();
		Vector3 pos = transform.position; // Turn it into a variable

		// If the player is on the ground and not touching its corners,
		// keep them on the ground
		if( myCol.bounds.min.y > col.bounds.max.y - .1F
		   && myCol.bounds.max.x != col.bounds.min.x
		   && myCol.bounds.min.x != col.bounds.max.x)
		{
			if(spinning)
				SpinStop();
			pos.y = col.bounds.max.y + transform.localScale.y / 2;
			platform = col;
			velocity.y = 0.0F;
		}
		// Otherwise, inside the left, right, bottom, or top somewhere
		else
		{
			Vector3 closest = col.ClosestPointOnBounds(transform.position);
			float relx = (closest.x - col.bounds.min.x) / col.bounds.size.x;
			float rely = (closest.y - col.bounds.min.y) / col.bounds.size.y;
			float relxOpp = 1.0F - relx;
			float relyOpp = 1.0F - rely;

			if ( relyOpp < rely && relyOpp < relx && relyOpp < relxOpp)
			{
				// Top
				pos.y = col.bounds.max.y + transform.localScale.y / 2;
				velocity.y = 0.0F;
				platform = col;
			}
			else if (relx < rely && relx < relxOpp && relx < relyOpp)
			{
				// Left
				pos.x = col.bounds.min.x - transform.localScale.x / 2;
				velocity.x = 0.0F;
				leftWall = true;
			}
			else if (rely < relxOpp && rely < relyOpp)
			{
				// Bottom
				if(!platform)
				{
					pos.y = col.bounds.min.y - transform.localScale.y / 2;
					velocity.y = 0.0F;
				}
			}
			else if (relxOpp < relyOpp)
			{
				// Right
				pos.x = col.bounds.max.x + transform.localScale.x / 2;
				velocity.x = 0.0F;
				rightWall = true;
			}
		}

		transform.position = pos;
	}

	void EnemyCollision(Collider col)
	{

		if(!invincible)
		{
			Enemy enemy = col.gameObject.GetComponent<Enemy> ();
			health -= enemy.strength;
			if (health <= 0)
				PlayerDeath ();
			health_text.text = health.ToString ();
			invincible = true;
			Vector3 heading =  transform.position - col.gameObject.transform.position;
			knockback = heading/heading.magnitude;
			knockback *= knockback_magnitude;
			knockback.z = 0;
			knockback_current_time = 0F;
		}
	}

	void PlayerDeath()
	{

	}

	void SpinJump()
	{	
		Vector3 scale = transform.localScale;
		scale.y = 1.499f;
		Vector3 pos = transform.position;
		pos.y = transform.position.y + transform.localScale.y / 2 - scale.y / 2;
		transform.localScale = scale;
		transform.position = pos;
		renderer.material = matSpin;
		spinning = true;
	}

	void SpinStop()
	{
		Vector3 scale = transform.localScale;
		scale.y = 1.99f;
		transform.localScale = scale;
		renderer.material = matStand;
		spinning = false;
	}

	void shoot(){
		if(isMorph || GameObject.FindGameObjectsWithTag("Player_Bullet").Length == 3){
			return;
		}
		else{
			GameObject newBullet = Instantiate(bulletFab) as GameObject;
			newBullet.transform.position = transform.position;
			newBullet.transform.position += Vector3.up*.3f;
			Bullet scriptb = newBullet.GetComponent<Bullet>();
			scriptb.velocity = Vector3.right * 15;
			if(longBeam)
				scriptb.lifeDistance = 16;
		}
	}

}

