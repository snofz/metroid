﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {

	public  Vector3 velocity;
	private Vector3 origin;
	public  float lifeDistance = 5.0f;

	// Use this for initialization
	void Start () {
		origin = transform.position;	
	}
	
	// Update is called once per frame
	void Update () {
		if (Vector3.Distance (origin, transform.position) > lifeDistance)
			Destroy (this.gameObject);
		transform.position += velocity * Time.deltaTime;
	}

	void OnTriggerEnter(Collider col){
		//print ("Bullet collided with: "+col.gameObject.name);
		if (col.gameObject.CompareTag ("Player"))
			return;
		if(col.gameObject.CompareTag("Enemy")){
			col.gameObject.GetComponent<Enemy>().damage(5);
		}
		Destroy (this.gameObject);
	}
}
