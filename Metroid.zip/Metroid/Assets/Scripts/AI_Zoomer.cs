using UnityEngine;
using System.Collections;

public class AI_Zoomer : MonoBehaviour {

	public float movespeed;
	private Vector3 velocity;
	public Collider platform = null;
	public Collider new_platform = null;

	// Use this for initialization
	void Start () {
		velocity.y = -1;
	}
	
	// Update is called once per frame
	void Update () {
		transform.position += velocity * Time.deltaTime;
	}

	void OnTriggerEnter(Collider col)
	{
		if(col.gameObject.CompareTag ("Wall"))
		{
			if(col != platform)
			{
				if(Physics.Raycast(transform.position, transform.TransformDirection (Vector3.right), .5f))
				{
					platform = col;
					new_platform = null;
					// Hit something on the right
					TurnCounterClockwise ();
				}
				else
					new_platform = col;
			}

		}
	}

	void OnTriggerStay(Collider col)
	{

	}

	void OnTriggerExit(Collider col)
	{
		if(col.gameObject.CompareTag ("Wall"))
		{
			if(platform == col && new_platform == null)
			{
				TurnClockwise();
				Vector3 pos = col.ClosestPointOnBounds(transform.position);
				float x = .98f * transform.localScale.x/2;
				float y = .98f * transform.localScale.y/2;
				if(velocity.x > 0)
					x *= -1;
				else if(velocity.x < 0)
					y *= -1;
				else if(velocity.y > 0)
				{
					x *= -1;
					y *= -1;
				}
				pos.x += x;
				pos.y += y;
				transform.position = pos;
			}
			else if(platform == col && new_platform)
			{
				platform = new_platform;
				new_platform = null;
			}
		}
	}

	void TurnCounterClockwise()
	{
		transform.rotation *= Quaternion.Euler (0, 0, 90);
		// Moving right
		if (velocity.x > 0)
		{
			velocity.x = 0;
			velocity.y = movespeed;
		}
		// Moving left
		else if (velocity.x < 0)
		{
			velocity.x = 0;
			velocity.y = -movespeed;
		}
		// Moving up
		else if (velocity.y > 0)
		{
			velocity.y = 0;
			velocity.x = -movespeed;
		}
		// Moving down
		else if (velocity.y < 0)
		{
			velocity.y = 0;
			velocity.x = movespeed;
		}
	}
	void TurnClockwise()
	{
		transform.rotation *= Quaternion.Euler (0, 0, -90);
		// Moving right
		if (velocity.x > 0)
		{
			velocity.x = 0;
			velocity.y = -movespeed;
		}
		// Moving left
		else if (velocity.x < 0)
		{
			velocity.x = 0;
			velocity.y = movespeed;
		}
		// Moving up
		else if (velocity.y > 0)
		{
			velocity.y = 0;
			velocity.x = movespeed;
		}
		// Moving down
		else if (velocity.y < 0)
		{
			velocity.y = 0;
			velocity.x = -movespeed;
		}
	}
}
