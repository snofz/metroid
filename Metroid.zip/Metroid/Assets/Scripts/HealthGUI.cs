﻿using UnityEngine;
using System.Collections;

public class HealthGUI : MonoBehaviour {

	public float offsetx;
	public float offsety;
	public Vector3 pos;

	// Use this for initialization
	void Start () {
		pos = transform.position;
		pos.x = Screen.width;
		pos.y = Screen.height;
		pos.x += offsetx;
		pos.y += offsety;
		transform.position = pos;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
