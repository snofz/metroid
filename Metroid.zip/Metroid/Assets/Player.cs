﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	public Vector3 maxVelocity;
	private Vector3 velocity;
	Collider platform = null;
	//Collider sidePlatform = null;
	bool canJump = false;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update()
	{
		velocity.x = maxVelocity.x * Input.GetAxis("Horizontal");
		
		/*if (platform)
		{
			Moving_Platform mp = platform.gameObject.GetComponent<Moving_Platform>();
			if(mp)
				velocity.x += mp.velocity.x;
		}*/
		
		if (Input.GetButton("Jump")) {
			if (platform)
			{
				platform = null;
				velocity.y += maxVelocity.y;
			}
			else if(canJump)
			{
				velocity -= 0.5F * Physics.gravity * Time.deltaTime;
			}
		}
		else if (!platform)
		{
			canJump = false;
		}
		
		// Not necessarily framerate independent
		Collider myCol = GetComponent<Collider>();
		if (!platform ||
		    myCol.bounds.max.x <= platform.bounds.min.x ||
		    myCol.bounds.min.x >= platform.bounds.max.x)
		{
			velocity += Physics.gravity * Time.deltaTime;
		}
		
		//Vector3 pos = transform.position; // Turn it into a variable
		transform.position += velocity * Time.deltaTime;
		
		//transform.position = pos;
	}
	
	void OnTriggerEnter(Collider col)
	{
		print("Collision detected.");
		
		platform = col;
		canJump = true;
		
		Collider myCol = GetComponent<Collider>();
		Vector3 pos = transform.position; // Turn it into a variable
		
		if(myCol.bounds.min.y > col.transform.position.y)
			pos.y = col.bounds.max.y + transform.localScale.y / 2;
		else
		{
			Vector3 closest = col.ClosestPointOnBounds(transform.position);
			float relx = (closest.x - col.bounds.min.x) / col.bounds.size.x;
			float rely = (closest.y - col.bounds.min.y) / col.bounds.size.y;
			float relxOpp = 1.0F - relx;
			float relyOpp = 1.0F - rely;
			
			if (relx < rely && relx < relxOpp && relx < relyOpp)
			{
				// Left
				pos.x = col.bounds.min.x - transform.localScale.x / 2;
			}
			else if (rely < relxOpp && rely < relyOpp)
			{
				// Bottom
				//sidePlatform = col;
				pos.y = col.bounds.min.y - transform.localScale.y / 2;
			}
			else if (relxOpp < relyOpp)
			{
				// Right
				//sidePlatform = col;
				pos.x = col.bounds.max.x + transform.localScale.x / 2;
			}
			else
			{
				// Top
				pos.y = col.bounds.max.y + transform.localScale.y / 2;
			}
		}
		
		velocity.y = 0.0F;
		transform.position = pos;
	}
	
	void OnTriggerStay(Collider col)
	{
		OnTriggerEnter(col);
	}
	
	//void OnTriggerExit(Collider col)
	//{
	//  platform = null;
	//}
}

