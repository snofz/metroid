using UnityEngine;
using System.Collections;

public class AI_Zoomer : MonoBehaviour {

	public float movespeed;
	private Vector3 velocity;
	private Collider platform = null;

	// Use this for initialization
	void Start () {
		velocity.y = -1;
	}
	
	// Update is called once per frame
	void Update () {


		transform.position += velocity * Time.deltaTime;
	}

	void OnTriggerEnter(Collider col)
	{
		if(col != platform)
		{
			platform = col;
			// Hit something on the right
			TurnCounterClockwise ();
		}
	}

	void OnTriggerStay(Collider col)
	{

	}

	void OnTriggerExit(Collider col)
	{
		if(platform == col)
		{
			TurnClockwise();
			Vector3 pos = col.ClosestPointOnBounds(transform.position);
			float x = .98f * transform.localScale.x/2;
			float y = .98f * transform.localScale.y/2;
			if(velocity.x > 0)
				x *= -1;
			else if(velocity.x < 0)
				y *= -1;
			else if(velocity.y > 0)
			{
				x *= -1;
				y *= -1;
			}
			pos.x += x;
			pos.y += y;
			transform.position = pos;
		}
	}

	void TurnCounterClockwise()
	{
		transform.rotation *= Quaternion.Euler (0, 0, 90);
		// Moving right
		if (velocity.x > 0)
		{
			velocity.x = 0;
			velocity.y = movespeed;
		}
		// Moving left
		else if (velocity.x < 0)
		{
			velocity.x = 0;
			velocity.y = -movespeed;
		}
		// Moving up
		else if (velocity.y > 0)
		{
			velocity.y = 0;
			velocity.x = -movespeed;
		}
		// Moving down
		else if (velocity.y < 0)
		{
			velocity.y = 0;
			velocity.x = movespeed;
		}
	}
	void TurnClockwise()
	{
		transform.rotation *= Quaternion.Euler (0, 0, -90);
		// Moving right
		if (velocity.x > 0)
		{
			velocity.x = 0;
			velocity.y = -movespeed;
		}
		// Moving left
		else if (velocity.x < 0)
		{
			velocity.x = 0;
			velocity.y = movespeed;
		}
		// Moving up
		else if (velocity.y > 0)
		{
			velocity.y = 0;
			velocity.x = movespeed;
		}
		// Moving down
		else if (velocity.y < 0)
		{
			velocity.y = 0;
			velocity.x = -movespeed;
		}
	}
}
